<p align="center">
  <a href="https://github.com/lucide-icons/lucide">
    <img src="https://lucide.dev/package-logos/lucide-vue.svg" alt="Lucide icon library for Vue applications." width="540">
  </a>
</p>

<p align="center">
Lucide icon library for Vue applications.
</p>

<div align="center">

  [![npm](https://img.shields.io/npm/v/@lucide/vue?color=blue)](https://www.npmjs.com/package/@lucide/vue)
  ![NPM Downloads](https://img.shields.io/npm/dw/@lucide/vue)
  [![License](https://img.shields.io/badge/license-ISC-green)](https://lucide.dev/license)
</div>

<p align="center">
  <a href="https://lucide.dev/guide/">About</a>
  ·
  <a href="https://lucide.dev/icons/">Icons</a>
  ·
  <a href="https://lucide.dev/guide/vue">Documentation</a>
  ·
  <a href="https://lucide.dev/license">License</a>
</p>

# Lucide Vue

Implementation of the lucide icon library for Vue applications.

## Installation

```sh
pnpm add @lucide/vue
```

```sh
npm install @lucide/vue
```

```sh
yarn add @lucide/vue
```

```sh
bun add @lucide/vue
```

## Documentation

For full documentation, visit [lucide.dev](https://lucide.dev/guide/packages/lucide-vue)

## Community

Join the [Discord server](https://discord.gg/EH6nSts) to chat with the maintainers and other users.

## License

Lucide is licensed under the ISC license. See [LICENSE](https://lucide.dev/license).

[//]: <> (Sponsors)

## Sponsors

<a href="https://vercel.com?utm_source=lucide&utm_campaign=oss">
  <img src="https://lucide.dev/vercel.svg" alt="Powered by Vercel" width="200" />
</a>

<a href="https://www.digitalocean.com/?refcode=b0877a2caebd&utm_campaign=Referral_Invite&utm_medium=Referral_Program&utm_source=badge"><img src="https://lucide.dev/digitalocean.svg" width="200" alt="DigitalOcean Referral Badge" /></a>

### Hero backers 🦸

<a href="https://zephyr-cloud.io/"><img src="https://lucide.dev/sponsors/zephyr-cloud.svg" width="180" alt="Zephyr Cloud – From idea to prod: fast micro-frontend delivery!" /></a>

### Awesome backers 🍺

<a href="https://github.com/pdfme/pdfme"><img src="https://lucide.dev/sponsors/pdfme.svg" width="180" alt="pdfme – Open-source PDF generation library built with TypeScript and React." /></a>
<a href="https://www.paxhistoria.co/"><img src="https://lucide.dev/sponsors/paxhistoria.svg?" width="180" alt="Pax Historia – An alternate history sandbox game" /></a>

### Backers ☕

<a href="https://www.fina.money/"><img src="https://lucide.dev/sponsors/fina-money.png" width="180" alt="Fina Money – Modular Finance Tracker" /></a>

### Other contributors 💸

You can find all our past and non-recurring financial contributors at [our Open Collective page](https://opencollective.com/lucide-icons).
